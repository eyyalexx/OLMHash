1. Open Terminal

2. Run the command (excluding the quotations): "gcc OPassword.c -o Q3". This will compile the .c file.

3. In terminal, run the command (excluding the quotations): "./Q3". (This command should be used everytime the user wants to run the program.)

4. The program will generate a .txt file with all possible 4-letter passwords and their corresponding hash values. Afterwards, the user will be prompted to enter a hash value. The program will return the corresponding 4-letter password.

5. Follow prompts in the terminal.
